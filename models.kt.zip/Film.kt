package com.example.helloworld.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable
import java.util.ArrayList

/**
 * Created by Oleur on 21/12/2014.
 * Film model represents a Star Wars single film.
 */
class Film : Serializable {
    var title: String? = null

    @SerializedName("episode_id")
    var episodeId = 0

    @SerializedName("opening_crawl")
    var openingCrawl: String? = null
    var director: String? = null
    var producer: String? = null
    var url: String? = null
    var created: String? = null
    var edited: String? = null

    @SerializedName("species")
    var speciesUrls: ArrayList<String>? = null

    @SerializedName("starships")
    var starshipsUrls: ArrayList<String>? = null

    @SerializedName("vehicles")
    var vehiclesUrls: ArrayList<String>? = null

    @SerializedName("planets")
    var planetsUrls: ArrayList<String>? = null

    @SerializedName("characters")
    var charactersUrls: ArrayList<String>? = null
}