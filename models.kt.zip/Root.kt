package com.example.helloworld.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

/**
 * Created by Oleur on 21/12/2014.
 * Root model that provides information on all avaiable resources within the API.
 */
class Root : Serializable {
    @SerializedName("films")
    var filmsUrl: String? = null

    @SerializedName("people")
    var peopleUrl: String? = null

    @SerializedName("planets")
    var planetsUrl: String? = null

    @SerializedName("species")
    var speciesUrl: String? = null

    @SerializedName("starships")
    var starshipsUrl: String? = null

    @SerializedName("vehicles")
    var vehiclesUrl: String? = null
}